﻿
using LivLong.Logger.Net8.Interface;
using Serilog;

namespace LivLong.Logger.Net8.Implementation
{
    public class LogWriter: ILogWriter
    {
        private string requestId;
        private Serilog.ILogger _logger;
        private string outputTemplate;

        public LogWriter(string serviceName)
        {
            this.outputTemplate = "{Timestamp:o} [{Level:u3}] {uuid} ({SourceContext}) {Message} {NewLine}";

            this.requestId = Guid.NewGuid().ToString();
            
            this._logger = new LoggerConfiguration()
                                .MinimumLevel.Information()
                                .WriteTo.Console(
                                    outputTemplate: outputTemplate
                                )
                                .WriteTo.File(
                                    path: $"Logs/Info/{serviceName}_.txt",
                                    rollingInterval: RollingInterval.Day,
                                    rollOnFileSizeLimit: true,
                                    shared: true,
                                    outputTemplate: outputTemplate
                                )
                                .Enrich.WithProperty("uuid", requestId)
                                .CreateLogger(); 
        }

        public void Information(string text)
        {
            _logger.Information(text);
        }

        public void Error(string text)
        {
            _logger.Error(text);
        }

        public void Warning(string text)
        {
            _logger.Warning(text);
        }

        public void Debug(string text) 
        {
            _logger.Debug(text);
        }

        public Serilog.ILogger GetLogger()
        {
            return _logger;
        }
    }
}
