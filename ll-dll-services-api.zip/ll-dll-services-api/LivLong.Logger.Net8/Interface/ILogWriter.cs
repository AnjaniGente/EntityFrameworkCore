﻿namespace LivLong.Logger.Net8.Interface
{
    public interface ILogWriter
    {
        void Information(string text);
        void Error(string text);
        void Warning(string text);
        void Debug(string text);
        Serilog.ILogger GetLogger();
    }
}
