﻿using LivLong.Logger.Net8.Implementation;
using LivLong.Logger.Net8.Interface;
using Microsoft.Extensions.DependencyInjection;

namespace LivLong.Logger.Net8.Initializer
{
    public static class LogInitializer
    {
        public static void RegisterLivLongLoggerDependancies(this IServiceCollection services, string serviceName)
        {
            services.AddScoped<ILogWriter>(x=> new LogWriter(serviceName));
        }
    }
}
