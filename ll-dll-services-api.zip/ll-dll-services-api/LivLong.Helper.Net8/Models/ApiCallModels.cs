﻿namespace LivLong.Helper.Net8.Models
{
    public class ApiCallModels
    {
    }

    public class ApiCallResponse
    {
        public bool is_error { get; set; }

        public string response_body { get; set; }

        public string x_auth_token { get; set; }

        public string session_id { get; set; }

    }
}
