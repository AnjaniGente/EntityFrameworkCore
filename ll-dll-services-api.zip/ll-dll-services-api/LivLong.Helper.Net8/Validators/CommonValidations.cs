﻿using System.Text.RegularExpressions;

namespace LivLong.Helper.Net8.Validators
{
    public static class CommonValidations
    {
        public static bool ValidateMobileNumber(string mobile_number)
        {
            try
            {
                if (!string.IsNullOrEmpty(mobile_number))
                {
                    if (mobile_number.All(char.IsDigit))
                    {
                        if (mobile_number.Length == 10)
                        {
                            return true;
                        }
                        return false;
                    }
                    return false;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        public static bool ValidateName(string name)
        {
            try
            {
                var pattern = "^[a-zA-Z0-9](?:[a-zA-Z0-9.,'_ -]*[a-zA-Z0-9])?$";
                var match = Regex.Match(name, pattern);

                if (match.Success)
                {
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        public static bool ValidateEmail(string email)
        {
            try
            {
                var pattern = "[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?";
                var match = Regex.Match(email, pattern);

                if (match.Success)
                {
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }
    }
}
