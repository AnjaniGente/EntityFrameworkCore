﻿using LivLong.Helper.Net8.Models;
using LivLong.Logger.Net8.Interface;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace LivLong.Helper.Net8.ApiCall
{
    public static class MakeApiCall
    {
        public static ILogWriter log;

        public static int requestCount = 1;

        public static async Task<ApiCallResponse> ApiCall(string apiUrl, dynamic apiRequestBody, string apiType, ILogWriter logger, string xAuthToken = null, string sessionId = null, bool responseTokenSessionRequired = false)
        {
            if (logger != null)
            {
                log = logger;
                requestCount += 1;
            }

            HttpClient client = new HttpClient();
            client.Timeout = TimeSpan.FromMinutes(1);
            try
            {
                if (client.DefaultRequestHeaders.Contains("Authorization"))
                {
                    client.DefaultRequestHeaders.Remove("Authorization");
                }

                if (!client.DefaultRequestHeaders.Contains("requestId"))
                {
                    client.DefaultRequestHeaders.Add("requestId", Guid.NewGuid().ToString());
                }

                log.Information($"{requestCount} ApiCall (API-URL): " + apiUrl);
                if (!string.IsNullOrWhiteSpace(xAuthToken))
                {
                    log.Information($"{requestCount}  ApiCall (API-URL): " + xAuthToken);
                    client.DefaultRequestHeaders.Add("x-auth-token", xAuthToken);
                }
                if (!string.IsNullOrWhiteSpace(sessionId))
                {
                    log.Information($"{requestCount} sessionId: " + sessionId);
                    client.DefaultRequestHeaders.Add("sessionId", sessionId);
                }

                log.Information($"{requestCount} postData: " + JsonConvert.SerializeObject(apiRequestBody));
                var httpContent = new StringContent(JsonConvert.SerializeObject(apiRequestBody), Encoding.UTF8, "application/json");
                dynamic httpResponse = null;

                if (apiType.ToUpper() == "POST")
                {
                    log.Information($"{requestCount} Calling Post Url: " + apiUrl);
                    httpResponse = await client.PostAsync(apiUrl, httpContent);
                }
                else if (apiType.ToUpper() == "PUT")
                {
                    log.Information($"{requestCount} Calling Put Url: " + apiUrl);
                    httpResponse = await client.PutAsync(apiUrl, httpContent);
                }
                else if (apiType.ToUpper() == "GET")
                {
                    log.Information($"{requestCount} Calling Get Url: " + apiUrl);
                    httpResponse = await client.GetAsync(apiUrl);
                }

                log.Information($"{requestCount} HttpResponse: " + JsonConvert.SerializeObject(httpResponse));
                if (httpResponse.IsSuccessStatusCode)
                {
                    var api_response = new ApiCallResponse { is_error = false };
                    api_response.response_body = httpResponse.Content.ReadAsStringAsync().Result;

                    if (responseTokenSessionRequired)
                    {
                        var headers = ((System.Net.Http.HttpResponseMessage)httpResponse).Headers;

                        if (headers.Contains("x-auth-token") && !string.IsNullOrWhiteSpace(headers.GetValues("x-auth-token").FirstOrDefault()))
                        {
                            api_response.x_auth_token = headers.GetValues("x-auth-token").FirstOrDefault();
                        }
                        if (headers.Contains("sessionId") && !string.IsNullOrWhiteSpace(headers.GetValues("sessionId").FirstOrDefault()))
                        {
                            api_response.session_id = headers.GetValues("sessionId").FirstOrDefault();
                        }
                    }

                    log.Information($"{requestCount} ApiCall Summary | Url: " + apiUrl + " | Payload: " + JsonConvert.SerializeObject(apiRequestBody) + " | Response: " + JsonConvert.SerializeObject(api_response));
                    return api_response;
                }
                else
                {
                    log.Information($"{requestCount} Api Call Failure Resson: " + httpResponse.ReasonPhrase.ToString());
                    return new ApiCallResponse
                    {
                        is_error = true,
                    };
                }
            }
            catch (Exception ex)
            {
                log.Error($"{requestCount} exception: " + ex.ToString().Replace("\n", "|"));
                return new ApiCallResponse
                {
                    is_error = true,
                    response_body = ex.ToString().Replace("\n", "|")
                };
            }
            finally
            {
                client.Dispose();
            }
        }

    }
}
