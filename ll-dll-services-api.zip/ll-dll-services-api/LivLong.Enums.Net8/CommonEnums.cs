﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace LivLong.Enums.Net8
{
    public static class CommonEnums
    {
        public enum LkpOrderStatus
        {
            Initiated = 1,
            Confirm = 2,
            Cancelled = 3,
            CancelInProcess = 4,
            NotConfirm = 5,
        }

        public enum LkpOrderType
        {
            WLOrder = 1,
            LabTestBooking = 2,
            DocBookAppointment = 3,
            InstanceConnect = 4,
        }

        public enum LkpPaymentMode
        {
            Cash = 1,
            Online = 2,
        }

        public enum LkpPaymentStatus
        {
            Initiated = 1,
            Failure = 2,
            Success = 3,
            Pending = 4,
            Cancel = 5,
            Refund = 6,
            NotFound = 7,
        }

        public enum LkpServiceTypes
        {
            Tele = 1,
            Clinic = 2,
            Home = 3,
        }


        public enum LkpProductType
        {
            Packages = 1,
            LabTest = 2,
            Consultation = 3,
            Medical = 4,
            Health_Care = 5,
            Diagnostics = 6,
            CT_Services = 7,
            Mental_Wellbeing = 8,
            Imaging_And_Scan = 9,
            ConsultationBasket = 10,
            LabTestBasket = 11,
            Dental = 12,
            Vision = 13,
            Vaccination = 14,
            Infertility = 15
        }

        public enum LkpBookingStatus
        {
            Allocated = 1,
            Completed = 2,
            Cancelled = 3,
            Rescheduled = 4,
            InProcess = 5,
            UnAllocated = 6,
            Initiated = 7,
        }

        public enum LkpAppointmentStatus
        {
            Confirmed = 1,
            Consultation_Complete = 2,
            Cancelled = 3,
            Rescheduled = 4,
            Customer_Not_Responding = 5,
            Call_Later = 6,
            Pending = 7,
            Awaiting_Lab_Confirmation = 8,
            Customer_Not_Answer = 9,
            COD = 10,
            Sample_Collected = 11,
            Pending_Physician_Review = 12,
            Report_Upload = 13,
            Report_QC = 14,
            Refund = 15,
            Physician_Review_Not_Required = 16,
            Awaiting_Physician_Confirmation = 17,
            Report_Awaited = 18,
            Partial_Sample_Collection = 19,
            Reports_Incomplete = 20,
            Cash_Collected = 21,
            Digitally_Paid = 22,
            Reschedule_Review = 23,
            Physician_Consulted_Show = 24,
            Not_Servicable_Pincode = 25,
            InProcess = 26,
            Payment_Collected = 27,
            Awaiting_For_Delivery = 28,
            Vendor_Modified = 29,
            Package_Picked = 30,
            Medicine_Delivered = 31,
            Awaiting_Vendor_Confirmation = 32,
        }

        public enum LkpLanguage
        {
            English = 1,
            Hindi = 2,
            Tamil = 3,
            Gujrati = 4,
            Marathi = 5,
            Telugu = 6,
        }
    }
}
