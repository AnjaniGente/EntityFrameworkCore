﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LivLong.Authentication.Net8.Data.Interface
{
    public interface IAuthDbStrategy
    {
        IAuthenticationContext GetContext();
    }
}
