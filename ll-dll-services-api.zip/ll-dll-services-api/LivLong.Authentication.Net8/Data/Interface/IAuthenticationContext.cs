﻿using LivLong.Authentication.Net8.Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LivLong.Authentication.Net8.Data.Interface
{
    public interface IAuthenticationContext : IDisposable
    {
        int SaveChanges();

        Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default);

        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);

        Microsoft.EntityFrameworkCore.Infrastructure.DatabaseFacade Database { get; }


        DbSet<UserSession> UserSession { get; set; }
    }
}
