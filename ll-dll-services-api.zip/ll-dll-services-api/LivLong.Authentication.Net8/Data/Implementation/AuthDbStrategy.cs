﻿using LivLong.Authentication.Net8.Data.Interface;
using LivLong.Authentication.Net8.Business.BusinessObjects;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LivLong.Authentication.Net8.Data.Implementation
{
    public class AuthDbStrategy : IAuthDbStrategy
    {
        private readonly IDbContextFactory<AuthenticationContext> contextFactory;

        public AuthDbStrategy(IDbContextFactory<AuthenticationContext> contextFactory)
        {
            this.contextFactory = contextFactory;
        }

        public IAuthenticationContext GetContext()
        {
            return contextFactory.CreateDbContext();
        }
    }
}
