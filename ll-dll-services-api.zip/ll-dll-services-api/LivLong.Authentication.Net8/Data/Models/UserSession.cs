﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LivLong.Authentication.Net8.Data.Models
{
    public class UserSession
    {
        public long Id { get; set; }
        public string LoginId { get; set; }
        public string AuthToken { get; set; }
        public string SessionId { get; set; }
        public string RequestDomain { get; set; }
        public DateTime SessionDateTime { get; set; }
        public int IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Source { get; set; }
    }
}
