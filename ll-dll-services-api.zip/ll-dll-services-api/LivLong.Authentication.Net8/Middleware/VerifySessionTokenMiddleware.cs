﻿using LivLong.Authentication.Net8.Business.Interface;
using LivLong.Common.Model;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LivLong.Authentication.Net8.Middleware
{
    public class VerifySessionTokenMiddleware: Attribute
    {
        private readonly RequestDelegate _next;

        public VerifySessionTokenMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            IAuthentication authentication = (IAuthentication)context.RequestServices.GetService(typeof(IAuthentication));

            var authenticationResponse = authentication.VerifySessionToken(context.Request.Headers);

            if (authenticationResponse.head.responseCode != 200)
            {
                context.Response.HttpContext.Response.StatusCode = authenticationResponse.head.errorCode;
                context.Response.ContentType = "application/json";
                await context.Response.WriteAsync(JsonConvert.SerializeObject(authenticationResponse));
                return;
            }
            else
            {
                await _next(context);
            }
        }
    }
}
