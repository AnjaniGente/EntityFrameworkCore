﻿using LivLong.Authentication.Net8.Business.Interface;
using LivLong.Authentication.Net8.Data.Implementation;
using LivLong.Authentication.Net8.Data.Interface;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection.Metadata;
using System.Runtime.CompilerServices;

namespace LivLong.Authentication.Net8.Initializer
{
    public static class Initializer
    {
        public static void RegisterLivLongAuthenticationDependancies(this IServiceCollection services, string serviceName, IConfiguration configuration)
        {

            services.AddScoped<IAuthenticationContext, AuthenticationContext>();

            services.AddScoped<IAuthDbStrategy, AuthDbStrategy>();

            services.AddScoped<IAuthentication, Business.Implementation.Authentication>();

            services.AddDbContextFactory<AuthenticationContext>(options =>
                options.UseSqlServer(
                    configuration.GetConnectionString("AuthenticationConnection")
                )
            );
        }
    }
}
