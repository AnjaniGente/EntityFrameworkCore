﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LivLong.Authentication.Net8.Business.BusinessObjects
{
    public class CommonModels { }

    public class HeaderKeyValue
    {
        public string key { get; set; }
        public string value { get; set; }
    }
}
