﻿using LivLong.Common.Model;
using Microsoft.AspNetCore.Http;

namespace LivLong.Authentication.Net8.Business.Interface
{
    public interface IAuthentication
    {
        ResponseViewModel VerifySessionToken(IHeaderDictionary headerDictionary);
    }
}
