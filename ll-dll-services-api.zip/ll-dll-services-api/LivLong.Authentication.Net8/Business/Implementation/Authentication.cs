﻿using LivLong.Authentication.Net8.Business.BusinessObjects;
using LivLong.Authentication.Net8.Business.Interface;
using LivLong.Authentication.Net8.Data.Interface;
using LivLong.Common.Enum;
using LivLong.Common.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LivLong.Authentication.Net8.Business.Implementation
{
    public class Authentication : IAuthentication
    {
        private IConfiguration configuration;
        private IAuthDbStrategy authDbStrategy;

        public Authentication(IConfiguration configuration, IAuthDbStrategy authDbStrategy)
        {
            this.configuration = configuration;
            this.authDbStrategy = authDbStrategy;
        }

        public ResponseViewModel VerifySessionToken(IHeaderDictionary headerDictionary)
        {
            try
            {
                if (GetConfigurationValueByKey("RequestSessionTokenCheck") == "1")
                {

                    var headerToken = headerDictionary.FirstOrDefault(x => x.Key.ToUpper() == "x-auth-token".ToUpper()).Value.ToString();
                    var sessionId = headerDictionary.FirstOrDefault(x => x.Key.ToUpper() == "sessionId".ToUpper()).Value.ToString();

                    if (!string.IsNullOrWhiteSpace(headerToken))
                    {
                        if (!string.IsNullOrWhiteSpace(sessionId))
                        {
                            var handler = new JwtSecurityTokenHandler();
                            var headerTokenDecoded = handler.ReadJwtToken(headerToken.Replace("Bearer ", ""));
                            string headerTokenLoginId = headerTokenDecoded.Claims.FirstOrDefault(s => s.Type == "unique_name").Value.ToString();

                            using (var context = authDbStrategy.GetContext())
                            {
                                if (!string.IsNullOrEmpty(headerTokenLoginId))
                                {
                                    var UserData = context.UserSession
                                                            .Where(x =>
                                                                        x.LoginId == headerTokenLoginId &&
                                                                        x.AuthToken == headerToken &&
                                                                        x.SessionId == sessionId &&
                                                                        x.IsActive == 1)
                                                            .ToList();

                                    if (UserData != null && UserData.Count() >= 1)
                                    {
                                        string requestOrigin = headerDictionary.FirstOrDefault(x => x.Key.ToUpper() == "origin".ToUpper()).Value.ToString();

                                        if (GetConfigurationValueByKey("RequestTokenUniqueNameCheck") == "1")
                                        {
                                            if (!string.IsNullOrWhiteSpace(requestOrigin))
                                            {
                                                List<string> domainList = GetConfigurationValueByKey("RequestOriginsForUniqueNameCheck").Split(";").ToList();

                                                if (domainList.Count > 0 && domainList.Any(x => x.ToString().ToUpper() == requestOrigin.ToUpper()))
                                                {
                                                    var headerLoginId = headerDictionary.FirstOrDefault(x => x.Key.ToUpper() == "loginId".ToUpper()).Value.ToString();

                                                    if (headerLoginId.ToUpper() != headerTokenLoginId.ToUpper())
                                                    {
                                                        return new ResponseViewModel
                                                        {
                                                            head = new HeadVM
                                                            {
                                                                errorCode = (int)ErrorVMCode.Unauthorized,
                                                                errorDescription = "Unauthorised Request: invalid login id",
                                                                responseCode = (int)ResponseVMCode.Failure
                                                            }
                                                        };
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                return new ResponseViewModel
                                                {
                                                    head = new HeadVM
                                                    {
                                                        errorCode = (int)ErrorVMCode.Unauthorized,
                                                        errorDescription = "Unauthorised Request: unknown request origin",
                                                        responseCode = (int)ResponseVMCode.Failure
                                                    }
                                                };
                                            }

                                        }
                                    }
                                    else
                                    {
                                        return new ResponseViewModel
                                        {
                                            head = new HeadVM
                                            {
                                                errorCode = (int)ErrorVMCode.Unauthorized,
                                                errorDescription = "Unauthorised Request: session expired",
                                                responseCode = (int)ResponseVMCode.Failure
                                            }
                                        };
                                    }
                                }
                                else
                                {
                                    return new ResponseViewModel
                                    {
                                        head = new HeadVM
                                        {
                                            errorCode = (int)ErrorVMCode.Unauthorized,
                                            errorDescription = "Unauthorised Request: invalid session token",
                                            responseCode = (int)ResponseVMCode.Failure
                                        }
                                    };
                                }
                            }
                        }
                        else
                        {
                            return new ResponseViewModel
                            {
                                head = new HeadVM
                                {
                                    errorCode = (int)ErrorVMCode.Unauthorized,
                                    errorDescription = "Unauthorised Request: session details not found",
                                    responseCode = (int)ResponseVMCode.Failure
                                }
                            };
                        }
                    }
                    else
                    {
                        return new ResponseViewModel
                        {
                            head = new HeadVM
                            {
                                errorCode = (int)ErrorVMCode.Unauthorized,
                                errorDescription = "Unauthorised Request: token details not found",
                                responseCode = (int)ResponseVMCode.Failure
                            }
                        };
                    }
                }
                return new ResponseViewModel
                {
                    head = new HeadVM
                    {
                        errorCode = 0,
                        errorDescription = "",
                        responseCode = (int)ResponseVMCode.Success
                    },
                    body = new BodyVM
                    {
                        msg = "User Verified",
                        responseData = true
                    }
                };
            }
            catch (Exception ex)
            {
                return new ResponseViewModel
                {
                    head = new HeadVM
                    {
                        errorCode = (int)ErrorVMCode.Unauthorized,
                        errorDescription = "Unauthorised request: " + ex.ToString().Replace("\n","|"),
                        responseCode = (int)ResponseVMCode.Failure
                    }
                };
            }
        }


        public string GetConfigurationValueByKey(string keyName)
        {
            try
            {
                var kayValue = configuration.GetSection(keyName).Exists() ?
                                    configuration.GetSection(keyName).Value.ToUpper()
                                    :
                                    "";
                if (string.IsNullOrWhiteSpace(kayValue))
                {
                    return "";
                }
                return kayValue.ToUpper();
            }
            catch (Exception ex)
            {
                return "";
            }
            return "";
        }
    }
}
